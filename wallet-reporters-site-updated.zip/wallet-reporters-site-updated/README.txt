Wallet Reporters — Cloudflare Pages (mockup-style)

Upload everything in this zip to your GitHub repo root (recommended) or directly into Pages.

Files:
- index.html
- registry.html
- styles.css
- main.js
- wallet-reporters-snippet.js
- assets/*

Notes:
- Partner logos in assets/ are placeholders. Swap with official assets once you have permission.
- This is a static demo; reports are stored in your browser (localStorage).
